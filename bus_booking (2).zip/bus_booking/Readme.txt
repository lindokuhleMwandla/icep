Template Used for this Project is a free template from the following website.
 https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/

